package com.mobility.syntel.gaugeexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CutomGaugeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cutom_gauge);
    }
}
