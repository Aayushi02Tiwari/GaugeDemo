package com.mobility.syntel.gaugeexample;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

//    ImageView mainIvSpeedometer;
//    LayerDrawable layerDrawable;
//    SpeedometerHelper speedometerHelper;
//    EditText et;
//    Button btn;
    int number;
    GaugeView gv_meter;
    Spinner spColor;
    int color;

    boolean first = true;

    private String[] colors = {"Blue","Green","Gray"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gv_meter = (GaugeView) findViewById(R.id.gv_view);


        spColor = findViewById(R.id.spColors);

        spColor.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, colors));
        spColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(first){
                    first = false;
                }else {

                    if(position == 0){
//                        gv_meter.setBgColor("#0a3d36");
//                        gv_meter.setBackgroundColor(Color.WHITE);
                        color = Color.parseColor("#0792f0");
                        gv_meter.setShowRangeValues(true);
                        gv_meter.setTargetValue(0);



                    }else if(position==1){
                        gv_meter.invalidate();
                        color = Color.parseColor("#13e8cb");
                        gv_meter.setShowRangeValues(true);
                        gv_meter.setTargetValue(45);

//                        gv_meter.setBackgroundColor(Color.YELLOW);
                    }else if(position == 2){
                        gv_meter.invalidate();
                        color = Color.parseColor("#A9A9A9");
//                        gv_meter.setBackgroundColor(Color.GREEN);
                        gv_meter.setShowRangeValues(true);
                        gv_meter.setTargetValue(30);
                    }else if(position == 3){
                        gv_meter.setShowRangeValues(true);
                        gv_meter.setTargetValue(45);
//                        gv_meter.setBackgroundColor(Color.BLUE);
                    }
                    gv_meter.initDrawingTools(color);
                    gv_meter.drawGauge();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });


//        gv_meter.setBgColor("#0a3d36");
        gv_meter.setShowRangeValues(true);
        gv_meter.setTargetValue(0);

//        CountDownTimer timer = new CountDownTimer(10000, 2) {
//            @Override
//            public void onTick(long millisUntilFinished) {
////                final int number = getIntent().getIntExtra("intVal",0);
////                gv_meter.setBgColor("#0a3d36");
//                gv_meter.setTargetValue(Float.valueOf(90));
//            }
//
//            @Override
//            public void onFinish() {
////                final int number = getIntent().getIntExtra("intVal",0);
////                gv_meter.setBgColor("#0a3d36");
//                gv_meter.setTargetValue(Float.valueOf(90));
//            }
//        };
//        timer.start();
//    }

//     static class A{
//
//        public static String _colorValue = "";
//
//        void sendValue(){
//            _colorValue  = "#e7202b";
//        }
//    }

}}
